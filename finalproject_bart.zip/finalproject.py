import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
import time as t
import scipy.integrate as scint
from numpy import fft

'''
Alexander Bart
PHGN498A Final Project
Balancing a Rigid Pendulum with a Cart
'''


''' Initial Values and Arrays '''

steps = int(10**4)
tfin = 60
dt = tfin/steps
m = 1 #Pendulum Mass
M = 1 #Cart mass
l = 1
g = 9.81

tarr = np.linspace(0,tfin,steps+1)

th = np.zeros(steps+1)
thd = np.zeros(steps+1)
x = np.zeros(steps+1)
xd = np.zeros(steps+1)
F = np.zeros(steps+1)

''' Equations of Motion '''

def fth(t,t_add,y,y_add):
    th_aprx = y + y_add
    return thd[t]

def fx(t,t_add,y,y_add):
    return xd[t]

def fthd(t,t_add,y,y_add):
    thd_aprx = y + y_add
    return (((F[t] + m*g*np.cos(th[t])*np.sin(th[t]) - \
    m*l*thd_aprx**2*np.sin(th[t]))\
    /(M+m-m*np.cos(th[t])**2))*np.cos(th[t])+g*np.sin(th[t]))/l

def fxd(t,t_add,y,y_add):
    xd_aprx = y + y_add
    return (F[t] + m*g*np.cos(th[t])*np.sin(th[t]) - \
    m*l*thd[t]**2*np.sin(th[t]))/(M+m-m*np.cos(th[t])**2)

''' Runge Kutta '''

def rk4(h,f,yn,xn):
    k1 = h*f(xn,0,yn,0)
    k2 = h*(f(xn,h/2,yn,k1*h/2)+k1/2)
    k3 = h*(f(xn,h/2,yn,k2*h/2)+k2/2)
    k4 = h*(f(xn,h,yn,k3*h)+k3)

    return yn+k1/6+k2/3+k3/3+k4/6

''' Time Evolution '''

alpha = 40
beta = 1
gamma = 20

th[0] = np.pi/3.7

for i in range(steps):
    th[i+1] = rk4(dt,fth,th[i],i)
    thd[i+1] = rk4(dt,fthd,thd[i],i)
    x[i+1] = rk4(dt,fx,x[i],i)
    xd[i+1] = rk4(dt,fxd,xd[i],i)

    #Getting back to origin
    if th[i] > -np.pi/64 and th[i] < 0:
        if x[i] < 0:
            F[i+1] = beta*x[i]
        elif x[i] > 0:
            F[i+1] = gamma
    elif th[i] < np.pi/64 and th[i] > 0:
        if x[i] < 0:
            F[i+1] = -gamma
        elif x[i] > 0:
            F[i+1] = -beta*x[i]

    #Nudging to top
    elif th[i] < -np.pi/64 and th[i] > -np.pi/32 and thd[i] > 0:
        F[i+1] = beta/th[i]
    elif th[i] < -np.pi/64 and th[i] > -np.pi/32 and thd[i] < 0:
        F[i+1] = -beta/th[i] + gamma
    elif th[i] > np.pi/64 and th[i] < np.pi/32 and thd[i] > 0:
        F[i+1] = -beta/th[i] - gamma
    elif th[i] > np.pi/64 and th[i] < np.pi/32 and thd[i] < 0:
        F[i+1] = beta/th[i]

    #Catching
    elif th[i] < 0:
        F[i+1] = -alpha*th[i]
    elif th[i] > 0:
        F[i+1] = -alpha*th[i]

''' Static Plots '''

plt.plot(tarr,th,'r',label = 'theta')
plt.plot(tarr,x,'b', label = 'cart position')
plt.legend()
plt.show()

''' Animation '''

x1 = x - l*np.sin(th)
y1 = l*np.cos(th)

xmin = min(x1)
xmax = max(x1)

fig = plt.figure()

ax = fig.add_subplot(111, aspect='equal', \
xlim=(xmin-0.5,xmax+0.5),ylim=(-0.5,l+0.5))

ax.set_ylabel('Y')
ax.set_title('Inverted Pendulum')
ax.grid()

p1, = ax.plot([],[], 'o-',lw=2)
p2, = ax.plot([],[], 's',lw=2)
cart_text = ax.text(0.02, 0.94, '', transform=ax.transAxes)
theta_text = ax.text(0.02, 0.84, '', transform=ax.transAxes)
force_text = ax.text(0.02, 0.89, '', transform=ax.transAxes)

def init():
    p1.set_data([],[])
    p2.set_data([],[])
    cart_text.set_text('')
    theta_text.set_text('')
    force_text.set_text('')
    return p1, cart_text, theta_text, force_text, p2

def animate(i):
    thisx1 = [x[i],x1[i]]
    thisy1 = [0,y1[i]]
    thisx2 = [x[i]]
    thisy2 = [0]

    p1.set_data(thisx1,thisy1)
    p2.set_data(thisx2,thisy2)
    cart_text.set_text('cart position = %.3f m' % x[i])
    theta_text.set_text('theta = %.3f pi' % (th[i]/(np.pi)))
    force_text.set_text('force = %.3f N' % F[i])
    return p1, cart_text, theta_text, force_text, p2

ani = animation.FuncAnimation(fig, animate, \
interval=1, blit=True, init_func=init)

plt.show()

''' Fourier Transforms '''
def fourier(tarr,arr,plot_label):
    plt.subplot(211)
    plt.plot(tarr,arr,'b',label = plot_label)
    plt.legend()
    plt.subplot(212)
    plt.plot(1/tarr,fft.fft(arr),'r',label = 'FT of '+plot_label)
    plt.legend()
    plt.show()

fourier(tarr,th,'theta')
fourier(tarr,x,'position')















###############################################################################
